// @ts-check
import { defineConfig } from 'astro/config';
import vercel from '@astrojs/vercel';
import sitemap from '@astrojs/sitemap';

// Produktions-URL der Seite. Bei eigener Domain hier anpassen
// (steuert Canonical-URLs, Sitemap und Open-Graph-Bild).
const SITE = process.env.SITE_URL || 'https://hufschmiede-weinberger.at';

// https://astro.build/config
export default defineConfig({
  site: SITE,
  output: 'server',
  adapter: vercel(),
  integrations: [
    sitemap({
      // Interner Bereich gehört nicht in die Sitemap.
      filter: (page) => !page.includes('/dashboard'),
    }),
  ],
});
